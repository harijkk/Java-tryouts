from django.contrib import admin
from.models import xam
admin.site.register(xam)

# Register your models here.
