from django.apps import AppConfig


class XamsConfig(AppConfig):
    name = 'xams'
