from django.db import models
from django import forms
RELIGION= [
    ('HINDU', 'HINDU'),
    ('CHRISTIAN', 'CHRISTIAN'),
    ('MUSLIM', 'MUSLIM'),
    ('OTHERS', 'OTHERS'),
    ]

class xam(models.Model):
    name=models.CharField(max_length=100)
    place=models.CharField(max_length=100)
    adhar=models.CharField(max_length=12)
    gender=models.CharField(max_length=3,name="gender")
    religion=models.CharField(max_length=10)
    bd=models.DateField(max_length=100)
    mail=models.EmailField(max_length=100)
    pic=models.ImageField(upload_to='profiles')
    def __str__(self):
        return self.name    

# Create your models here.
